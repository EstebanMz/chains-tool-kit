PAPER TOWN 1 

V1.2
By CapitaineSZM & EstebanMz
---------------------------------------------------------------------------------------------------

Thank you for downloading Paper town 1! Hope you will enjoy this track, inspired by paper-mario
like aesthetics

Why Paper Town 1? Paper Town 2 is a scrapped project using some of the old textures in those files. Maybe
I'll try to work more on it some other day. Just in case, I'll leave the enigmatic '1'





V1.2 - Improved by CapitaineSZM & EstebanMz
---------------------------------------------------------------------------------------------------

- Better AI for regular version
- Invisible oil fix
- Overall graphic update
- New force fields to avoid collision
- Fixed collision and reduced amount of polygons

--------------------------------
Latest RVGL update is required!
--------------------------------

Credits:
--------

- Houses, bench and potted plants models are from Townscaper, check out this "game", worth a try!
- Song : Nothing stops detroit - Professor Kliq. Go support him and his work here!
https://www.professorkliq.com/


Future improvements:
--------------------

If I somehow get motivated to animated custom animations, I'll probably animate the paper airplanes.
I could also focus on cameras for replays, but my knowledge is limited at this moment.


Feedback:
---------

As always, please send me your feedback! You can reach me on Discord CapitaineSZM#7490
or by mail, capitaineszm@gmail.com


Thanks:
-------

As always, special thanks to RV/IO team and discord for continuous help with those tricky tools.
Thanks Tubers for general pre-release feedback.
Special Thanks to MisterMV and Z-Event, for their infinite positivity.

And thank you for still playing this game 20 years later. Let's aim for 20 more!

Have fun,
Capi