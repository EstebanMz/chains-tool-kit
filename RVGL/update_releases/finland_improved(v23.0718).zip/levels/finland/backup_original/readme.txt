                                                                        October 2005
=================================================
Track name:  Finland
Author:  hilaire9
Track length:  729 meters                                      
Type:  Extreme
===============================================================================
*** Track Installation:  Extract into your Revolt folder
------------------------------------------------
*** Description:  

                  Survival in Finland is still difficult and the winters are long, cold, and dark. 
                  During my stay I spent much time fighting the elements to stay alive: Ravenous 
                  giant rabid reindeer and man-eating moose with a voracious appetite for human flesh 
                  roam the villages after dark. Packs of polar bears stalk the streets of Helsinki mauling
                  unsuspecting Finns. More than once I have seen a gaggle of a hundred or more penguins
                  swoop down from the sky like hungry vultures to tear an unsuspecting Finn limb from limb.

                                                                                                    --- Sir hilaire9, world traveler 
-------------------------------------------------
* Thanks to *

    Jimk / things from his Off-Road Kit
    RST / duck and fish model prms
    Walls, floors and ceiling  prms are textured Lego floor pieces.    
    Soldier of Fortune 2 / most of the textures
  
----------- Built with rvGlue, MAKEITGOOD edit modes, rv-Sizer,  PSP7
                and MS Paint.

----------- hilaire9's Home Page:  http://members.cox.net/alanzia
====================================================================================
