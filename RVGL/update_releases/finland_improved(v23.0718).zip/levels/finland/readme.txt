=================================================
July 2023
=================================================
Track Edit: Finland: Improved Edition
Authors: EstebanMz, yun

WARNING: This mod is not compatible for multiplayer mod, unless every player have it installed.

List of changes:
- Reverse version added. To make it possible, both world and collision files were modified to allow cars to go in the opposite way.
- Improved AI with the help of yun for normal and reverse mode, as much as it's possible due to many cars just spin non-stop when 
they lose control, due to the slippery surface in most of the track, specifically on Pro and Super Pro classes.
- Fixed collision properties at some sections of the track that had the Default property when it shouldn't.
- Modified track properties for Ice and a new "Wet Gravel", based on the snow from Snowland 1 by Xarc.
- More Pick-ups and a Global Star were added (thanks yun).
- Added a new skybox taken from Aspenside R (thanks Tubers for your permission).
- Visiboxes and custom ENV were removed.

=================================================
October 2005
=================================================
Track name:  Finland
Author:  hilaire9
Track length:  729 meters                                      
Type:  Extreme
===============================================================================
*** Track Installation:  Extract into your Revolt folder
------------------------------------------------
*** Description:  

                  Survival in Finland is still difficult and the winters are long, cold, and dark. 
                  During my stay I spent much time fighting the elements to stay alive: Ravenous 
                  giant rabid reindeer and man-eating moose with a voracious appetite for human flesh 
                  roam the villages after dark. Packs of polar bears stalk the streets of Helsinki mauling
                  unsuspecting Finns. More than once I have seen a gaggle of a hundred or more penguins
                  swoop down from the sky like hungry vultures to tear an unsuspecting Finn limb from limb.

                                                                                                    --- Sir hilaire9, world traveler 
-------------------------------------------------
* Thanks to *

    Jimk / things from his Off-Road Kit
    RST / duck and fish model prms
    Walls, floors and ceiling  prms are textured Lego floor pieces.    
    Soldier of Fortune 2 / most of the textures
  
----------- Built with rvGlue, MAKEITGOOD edit modes, rv-Sizer,  PSP7
                and MS Paint.

----------- hilaire9's Home Page:  http://members.cox.net/alanzia
====================================================================================
