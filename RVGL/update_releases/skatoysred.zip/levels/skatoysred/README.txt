Everything that I made here can be reused, credit is appreciated but not mandatory.
